
<?php $__env->startSection('content'); ?>
    <div class="movie-detail border-b border-gray-800">
        <div class="container mx-auto px-4 py-16 lg:flex md:flex sm:flex gap-4 ">
            <img src="<?php echo e(asset('/uploads/movies/thumb/'.$movie->image)); ?>" class="w-full" style="width: 15rem; height:24rem" alt="">
            <div class="lg:ml-24">
                <h2 class="text-4xl font-semibold text-white"><?php echo e($movie->title); ?></h2>
                <div class="">

                    <p class="info text-white">by <?php echo e($movie->director); ?></p>
                    <div class="star-rating d-inline-flex " title="">
                        
                        <div class="star-rating d-inline-flex ml-2" title="">
                            <?php
                                $averageRating = round($averageRating); // Round the average rating to the nearest whole number
                            ?>
                            <span class="rating-text theme-font text-white theme-yellow info"><?php echo e(number_format($averageRating, 1)); ?></span>
                            <div class="star-rating d-inline-flex mx-2" title="">
                                <?php for($i = 1; $i <= 5; $i++): ?>
                                    <?php if($i <= $averageRating): ?>
                                        <i class="fa fa-star text-yellow-400 info" aria-hidden="true"></i>
                                    <?php else: ?>
                                        <i class="fa fa-star-o info" aria-hidden="true"></i>
                                    <?php endif; ?>
                                <?php endfor; ?>
                            </div>
                        </div>
                        
                        <br><br/>
                        
                    </div>
                    <p class="theme-font text-white  info"><?php echo e($reviewCount); ?> Reviews</p>
                    <p><?php echo e($movie->discription); ?></p>
                </div>
            </div>
            <div>
                <iframe class="mx-5 lg:w-[560px] lg:h-[315px] w-1/2 h-1/6"  src="<?php echo e($movie->trailer); ?>" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" referrerpolicy="strict-origin-when-cross-origin" allowfullscreen></iframe>
            </div>
        </div>

        <section class="container">
            <div class="flex w-full justify-between items-center container">
                <h2 class="text-indigo-500">Reviews</h2>
                <button onclick="openPopup()" class="rounded bg-red-600 px-2 py-1">Add Review</button>
            </div>
            <div class="container">
                <div id="reviewsSection ">
                    <!-- Loop through each review -->
                    <?php $__currentLoopData = $movie->reviews; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $review): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="review">
                            <p class="review-rating text-white"><span><i class="fa fa-star info text-yellow-500" aria-hidden="true"></i></span><?php echo e($review->rating); ?>/5</p>
                            <p class="review-text text-white"><?php echo e($review->comment); ?></p>
                            <!-- Display the user who made the review -->
                            <p class="review-user text-white">By: <?php echo e($review->user ? $review->user->name : 'Unknown'); ?></p>

                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
                
                <p></p>
      

            </div>
            <?php if(Auth::check()): ?>
                
            
            <div id="reviewPopup" class="review-popup">
                <form action="<?php echo e(route('movies.submit-review', ['id' => $movie->id])); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <div class="form-group">
                        <input type="hidden" name="movie_id" value="<?php echo e($movie->id); ?>">
                        <label for="comment">Your Review</label>
                        <textarea class="form-control" id="comment" name="comment" rows="3"></textarea>
                    </div>
                    <div class="form-group">
                        <label for="rating">Rating (1-5)</label>
                        <input type="number" class="form-control" id="rating" name="rating" min="1" max="5">
                    </div>
                    <button type="submit" class="btn btn-primary">Submit Review</button>
                </form>
                
            </div>
            <?php else: ?>
            <h3 class=" absolute    z-50 ">User not found</h3>
            <?php endif; ?>
        </section>

    </div>
    <script>
        function openPopup() {
    document.getElementById("reviewPopup").style.display = "flex";
}

function closePopup() {
    document.getElementById("reviewPopup").style.display = "none";
}

function submitReview() {
    
    var review = document.getElementById("reviewTextarea").value;
    var rating = document.getElementById("ratingInput").value;
   

    // Here you can send the review and rating data to the server using AJAX
    // Example: You can use fetch or XMLHttpRequest to send data to your backend
    // After successful submission, you can close the pop-up and update the UI as needed

    closePopup(); // Close the pop-up after submission
}

    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.masterlayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\movie-review-app\resources\views/movies/detail.blade.php ENDPATH**/ ?>