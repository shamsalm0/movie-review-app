<?php $__env->startSection('content'); ?>
    


<div class="container">
    <div class="row my-5">
        <div class="col-md-3">
            <div class="card border-0 shadow-lg">
                <div class="card-header  text-white">
                    Welcome, <?php echo e(Auth::user()->name); ?>                        
                </div>
                <div class="card-body">
                    <div class="text-center mb-3">
                        <img src="<?php echo e(asset('uploads/profile/thumb/'.Auth::user()->image)); ?>" class="img-fluid rounded-circle" alt="Luna John">                            
                    </div>
                    <div class="h5 text-center">
                        <strong><?php echo e(Auth::user()->name); ?></strong>
                        <p class="h6 mt-2 text-muted">5 Reviews</p>
                    </div>
                </div>
            </div>
            <div class="card border-0 shadow-lg mt-3">
                <div class="card-header  text-white">
                    Navigation
                </div>
                <div class="card-body sidebar">
                    <ul class="nav flex-column">
                        <?php if(Auth::user()->role == 'admin'): ?>
                        <li class="nav-item">
                            <a href="<?php echo e(route('movies.index')); ?>">Movies</a>                               
                        </li>
                        <li class="nav-item">
                            <a href="reviews.html">Reviews</a>                               
                        </li>
                        <?php endif; ?>
                        <li class="nav-item">
                            <a href="profile.html">Profile</a>                               
                        </li>
                        <li class="nav-item">
                            <a href="my-reviews.html">My Reviews</a>
                        </li>
                        <li class="nav-item">
                            <a href="change-password.html">Change Password</a>
                        </li> 
                        <li class="nav-item">
                            <a href="login.html">Logout</a>
                        </li>                           
                    </ul>
                </div>
            </div>                
        </div>
        <div class="col-md-9">
            
            <div class="card border-0 shadow">
                <div class="card-header  text-white">
                    movies
                </div>
                <div class="card-body pb-0">            
                    <div class="d-flex justify-content-between">
                        <div><a href="<?php echo e(route('movies.create')); ?>" class="btn btn-primary ">Add Movies</a> </div>

                       <form action="" method="get">
                        <div class="d-flex  gap-1">
                            <input type="text" class="form-control" name="keyword" value="<?php echo e(Request::get('keyword')); ?>" id="" placeholder="Search MovieBuzz">
                            <button class="rounded" type="submit">search</button>
                            <a href="<?php echo e(route('movies.index')); ?>" class="btn btn-secondary ms-2">clear</a>
                        </div>
                       </form>
                    </div>  
                    <?php if(Session::has('success')): ?>
                    <div class="alert alert-success">
                        <?php echo e(Session::get('success')); ?>

                    </div>
                <?php endif; ?>         
                    <table class="table  table-striped mt-3">
                        <thead class="table-dark">
                            <tr>
                                <th>Title</th>
                                <th>Director</th>
                                <th>Rating</th>
                                <th>Status</th>
                                <th width="150">Action</th>
                            </tr>
                            <tbody>
                                <?php if($movies->isNotEmpty()): ?>
                                    <?php $__currentLoopData = $movies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $movie): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($movie->title); ?></td>
                                        <td><?php echo e($movie->director); ?></td>
                                        <td>3.0 (3 Reviews)</td>
                                        <td>
                                            <?php if($movie->status ==1): ?>
                                            <span class="text-success">Active</span>
                                                <?php else: ?>
                                                <span class="text-danger">Block</span>
                                            <?php endif; ?>
                                        </td>
                                        <td>
                                            <a href="#" class="btn btn-success btn-sm"><i class="fa-regular fa-star"></i></a>
                                            <a href="<?php echo e(route('movies.edit',$movie->id)); ?>" class="btn btn-primary btn-sm"><i class="fa-regular fa-pen-to-square"></i>
                                            </a>
                                            <form action="<?php echo e(route('movies.drop', $movie->id)); ?>" method="post" style="display: inline;">
                                                <?php echo csrf_field(); ?>
                                                <?php echo method_field('DELETE'); ?>
                                                <button type="submit" class="btn btn-danger btn-sm" onclick="return confirm('Are you sure you want to delete?')">
                                                    <i class="fa-solid fa-trash"></i>
                                                </button>
                                            </form>
                                        </td>
                                    </tr>  
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php else: ?>
                                    <tr>
                                        <td colspan="5">
                                            <p>Books not found</p>
                                        </td>
                                    </tr>
                                <?php endif; ?>

                           
                            </tbody>
                        </thead>
                    </table>  
                    
                       <?php if($movies->isNotEmpty()): ?>
                       <?php echo e($movies->links()); ?>   
                       <?php endif; ?>
                    
                    
                   
                    
                </div>
                
            </div>                
        </div>
    </div>       
</div>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.masterlayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\movie-review-app\resources\views/movies/list.blade.php ENDPATH**/ ?>