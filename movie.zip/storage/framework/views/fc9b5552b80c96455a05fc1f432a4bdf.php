
<?php $__env->startSection('style'); ?>
<link rel="stylesheet" href=<?php echo e(asset('css/home.css')); ?>>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="container mt-3 pb-5">
    <div class="row justify-content-center d-flex mt-5">
        <div class="col-md-12">
           
            <div class="card shadow-lg  col-lg-12 col-md-12  border-0">
           
            </div>
            <div class="row mt-4">
               <?php $__currentLoopData = $movies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $movie): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
         
            <div class="col-md-4 col-lg-3 mb-4">
                <div class=" card-container  mx-auto m-lg-0 m-md-0">
                    <?php if($movie->image != ''): ?>
                    
                        <div class="poster">
                            
                            <a href="<?php echo e(route('movies.detail',$movie->id)); ?>"><img src="<?php echo e(asset('/uploads/movies/thumb/'.$movie->image)); ?>" alt="" class="card-img-top w-full h-full" height="300" width="300" ></a>
                        </div>
                    
                    <?php else: ?>
                    <a href="detail.html"><img src="https://www.freeiconspng.com/img/23485" alt="" class="card-img-top " height="300" width="300" ></a>
                    <?php endif; ?>
                   <a href=""class='movie-link'>
                    <div class="card-body-container">
                        <a href="<?php echo e(route('movies.detail',$movie->id)); ?>"><svg xmlns="http://www.w3.org/2000/svg"style="height: 30px !important; width: 50px !important;" viewBox="0 0 25 25"><path  style="fill:#babaca" d="m17.5 5.999-.707.707 5.293 5.293H1v1h21.086l-5.294 5.295.707.707L24 12.499l-6.5-6.5z" data-name="Right"/></svg></a>
                        <h3 class="h4 heading"><a href="<?php echo e(route('movies.detail',$movie->id)); ?>"><?php echo e($movie->title); ?></a></h3>
                        <p class="info">by <?php echo e($movie->director); ?></p>
                        <div class="star-rating d-inline-flex ml-2" title="">
                          <?php
                              $averageRating = round($movie->averageRating);
                              $reviewCount = round($movie->reviewCount)
                          ?>
                             <span class="rating-text theme-font text-white theme-yellow info"><?php echo e(number_format($averageRating, 1)); ?></span>
                             <div class="star-rating d-inline-flex mx-2">
                                <?php for($j=1;$j<=5;$j++): ?>
                                    <?php if($j <= $averageRating): ?>
                                    <i class="fa fa-star text-yellow-400 info" aria-hidden="true"></i>
                                    <?php else: ?>
                                    <i class="fa fa-star-o info" aria-hidden="true"></i>
                                    <?php endif; ?>
                                <?php endfor; ?>
                             </div>
                            <br><br/>
                            
                        </div>
                        <p class="theme-font text-white  info"><?php if($reviewCount): ?>
                            <?php echo e($reviewCount); ?> Reviews
                            <?php else: ?>
                            <p></p>
                        <?php endif; ?></p>
                    </div>
                </a>
                </div>
            </div>
        
               <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php echo e($movies->links()); ?>

                
                
            </div>
        </div>
    </div>
</div>    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.masterlayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\movie-review-app\resources\views/home/home.blade.php ENDPATH**/ ?>